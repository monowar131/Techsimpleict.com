<?php
$host = 'localhost'; // WATCH OUT: You gave your website link. You must use the "MySQL Host Name" (starts with "sql", like sql101.infinityfree.com)
$db   = 'if0_41355285_training';
$user = 'if0_41355285';
$pass = 'Monowar131@';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
     $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
     throw new \PDOException($e->getMessage(), (int)$e->getCode());
}
?>
